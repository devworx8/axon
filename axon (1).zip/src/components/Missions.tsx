import React, { useState, useEffect } from "react";
import { CheckCircle2, Circle, Clock, AlertCircle, Plus, MoreVertical, Calendar, User } from "lucide-react";
import { cn } from "@/src/lib/utils";

export default function Missions() {
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/tasks").then(res => res.json()).then(data => {
      setTasks(data);
      setLoading(false);
    });
  }, []);

  const priorityColor = (p: string) => {
    switch (p) {
      case "urgent": return "text-rose-400 bg-rose-500/10 border-rose-500/20";
      case "high": return "text-amber-400 bg-amber-500/10 border-amber-500/20";
      case "medium": return "text-blue-400 bg-blue-500/10 border-blue-500/20";
      default: return "text-slate-400 bg-slate-500/10 border-slate-500/20";
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Missions</h1>
          <p className="text-slate-500 text-sm">Track and execute actionable goals across your environment.</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold transition-all flex items-center gap-2 shadow-lg shadow-blue-600/20">
            <Plus className="w-4 h-4" /> Create Mission
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {loading ? (
          [1, 2, 3].map(i => (
            <div key={i} className="h-20 rounded-2xl bg-slate-900/50 border border-slate-800 animate-pulse" />
          ))
        ) : tasks.length > 0 ? (
          tasks.map((task) => (
            <div key={task.id} className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-all group flex items-center gap-4">
              <button className="p-1 rounded-lg text-slate-600 hover:text-emerald-400 transition-colors">
                <Circle className="w-5 h-5" />
              </button>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1">
                  <h3 className="text-sm font-semibold text-slate-200 truncate">{task.title}</h3>
                  <span className={cn(
                    "text-[9px] px-2 py-0.5 rounded-full border font-bold uppercase tracking-widest",
                    priorityColor(task.priority)
                  )}>
                    {task.priority}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-[10px] text-slate-500 font-medium">
                  <div className="flex items-center gap-1.5">
                    <div className="w-1 h-1 rounded-full bg-blue-500" />
                    {task.project_name || "General"}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3 h-3" />
                    {task.due_date ? new Date(task.due_date).toLocaleDateString() : "No due date"}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <User className="w-3 h-3" />
                    Operator
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="p-20 rounded-3xl border border-dashed border-slate-800 text-center space-y-4">
            <div className="text-slate-600 text-5xl">✅</div>
            <div className="space-y-1">
              <div className="text-slate-300 font-bold">No active missions</div>
              <p className="text-slate-500 text-sm max-w-xs mx-auto">Missions are specific, trackable goals. Create one manually or let Axon suggest some.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
