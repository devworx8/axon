import React, { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Paperclip, Sparkles, StopCircle, Terminal, Maximize2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { cn } from "@/src/lib/utils";
import { chat } from "@/src/lib/gemini";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  status?: "sending" | "sent" | "error";
}

export default function Console() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
      status: "sent"
    };

    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role === "user" ? "user" : "model",
        parts: [{ text: m.content }]
      }));

      const response = await chat(input, history);

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response || "I'm sorry, I couldn't process that.",
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (error) {
      console.error("Chat error:", error);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "⚠️ Connection to brain lost. Please check your API key or network.",
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 relative">
      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-6 max-w-md mx-auto">
            <div className="w-20 h-20 rounded-[28px] bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-4xl shadow-2xl shadow-blue-500/20 animate-pulse">
              ✦
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold text-white">Axon Console</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Give Axon a goal and let it observe, plan, and execute. You can ask about your workspaces, manage missions, or run local tools.
              </p>
            </div>
            <div className="grid grid-cols-1 gap-2 w-full">
              {[
                "Summarize my active workspaces",
                "Suggest 3 new missions for today",
                "Check the health of my projects"
              ].map((hint, i) => (
                <button 
                  key={i}
                  onClick={() => setInput(hint)}
                  className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 hover:border-blue-500/50 hover:bg-slate-800 transition-all text-left"
                >
                  {hint}
                </button>
              ))}
            </div>
          </div>
        )}

        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={cn(
                "flex gap-4",
                msg.role === "user" ? "flex-row-reverse" : "flex-row"
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-xl shrink-0 flex items-center justify-center text-sm font-bold shadow-lg border border-white/10",
                msg.role === "user" ? "bg-slate-800 text-slate-300" : "bg-gradient-to-br from-blue-500 to-blue-700 text-white"
              )}>
                {msg.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>
              <div className={cn(
                "max-w-[80%] space-y-2",
                msg.role === "user" ? "items-end" : "items-start"
              )}>
                <div className={cn(
                  "px-4 py-3 rounded-[24px] text-sm leading-relaxed shadow-sm",
                  msg.role === "user" 
                    ? "bg-blue-600 text-white rounded-tr-md" 
                    : "bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-md"
                )}>
                  <div className="prose prose-invert prose-sm max-w-none">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                </div>
                <div className="text-[10px] text-slate-500 px-2">
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isLoading && (
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center shadow-lg border border-white/10">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-[24px] rounded-tl-md px-4 py-3 flex gap-1.5 items-center">
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-6 border-t border-slate-800 bg-slate-950/80 backdrop-blur-xl shrink-0">
        <div className="max-w-4xl mx-auto relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-2xl blur opacity-0 group-focus-within:opacity-100 transition duration-500" />
          <div className="relative flex items-end gap-2 bg-slate-900 border border-slate-800 rounded-2xl p-2 pl-4 focus-within:border-blue-500/50 transition-all">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Type a goal or ask Axon..."
              rows={1}
              className="flex-1 bg-transparent border-none focus:ring-0 text-sm py-2.5 resize-none max-h-40 placeholder:text-slate-500"
            />
            <div className="flex items-center gap-1 pb-1 pr-1">
              <button className="p-2 rounded-xl text-slate-500 hover:text-slate-300 hover:bg-slate-800 transition-colors">
                <Paperclip className="w-4 h-4" />
              </button>
              <button 
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className={cn(
                  "p-2.5 rounded-xl transition-all shadow-lg",
                  input.trim() && !isLoading 
                    ? "bg-blue-600 text-white shadow-blue-600/20 hover:bg-blue-500" 
                    : "bg-slate-800 text-slate-600"
                )}
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
        <div className="mt-3 flex items-center justify-center gap-4 text-[10px] text-slate-600 font-bold uppercase tracking-widest">
          <span className="flex items-center gap-1.5"><Sparkles className="w-3 h-3" /> Agent Mode</span>
          <span className="w-1 h-1 rounded-full bg-slate-800" />
          <span className="flex items-center gap-1.5"><Terminal className="w-3 h-3" /> Guarded Actions</span>
          <span className="w-1 h-1 rounded-full bg-slate-800" />
          <span className="flex items-center gap-1.5"><Maximize2 className="w-3 h-3" /> Full Context</span>
        </div>
      </div>
    </div>
  );
}
