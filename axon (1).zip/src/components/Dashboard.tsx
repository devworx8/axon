import React, { useState, useEffect } from "react";
import { Activity, CheckCircle2, AlertCircle, Clock, ArrowRight, Zap, Shield, Cpu } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/src/lib/utils";

export default function Dashboard() {
  const [stats, setStats] = useState({
    activeWorkspaces: 0,
    openMissions: 0,
    healthAvg: 0,
    tokensUsed: 0
  });

  const [recentActivity, setRecentActivity] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/projects").then(res => res.json()).then(data => {
      const healths = data.map((p: any) => p.health);
      setStats(prev => ({
        ...prev,
        activeWorkspaces: data.length,
        healthAvg: healths.length ? Math.round(healths.reduce((a: any, b: any) => a + b, 0) / healths.length) : 0
      }));
    });

    fetch("/api/tasks").then(res => res.json()).then(data => {
      setStats(prev => ({ ...prev, openMissions: data.length }));
    });

    fetch("/api/activity").then(res => res.json()).then(data => {
      setRecentActivity(data);
    });
  }, []);

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Hero Section */}
      <section className="relative rounded-[32px] border border-blue-500/15 bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-900/80 p-8 shadow-2xl overflow-hidden group">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-blue-500/5 to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start gap-8">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-4">
              <div className="px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-[10px] font-bold text-blue-400 uppercase tracking-widest">
                Operator Console
              </div>
              <div className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-bold text-emerald-400 uppercase tracking-widest">
                Ready
              </div>
            </div>
            <h1 className="text-4xl font-bold text-white mb-4 tracking-tight">
              Good morning, Operator.
            </h1>
            <p className="text-slate-400 text-lg leading-relaxed mb-6">
              Axon is monitoring your local environment. You have <span className="text-blue-400 font-semibold">{stats.activeWorkspaces} active workspaces</span> and <span className="text-amber-400 font-semibold">{stats.openMissions} open missions</span> requiring attention.
            </p>
            <div className="flex flex-wrap gap-3">
              <button className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all shadow-lg shadow-blue-600/20 flex items-center gap-2 group/btn">
                Open Console <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
              </button>
              <button className="px-6 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold transition-all border border-slate-700">
                Run Environment Scan
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 w-full md:w-auto shrink-0">
            <div className="p-6 rounded-3xl bg-slate-950/50 border border-slate-800 backdrop-blur-sm">
              <div className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mb-2">System Health</div>
              <div className={cn(
                "text-3xl font-bold",
                stats.healthAvg >= 80 ? "text-emerald-400" : stats.healthAvg >= 50 ? "text-amber-400" : "text-rose-400"
              )}>
                {stats.healthAvg}%
              </div>
            </div>
            <div className="p-6 rounded-3xl bg-slate-950/50 border border-slate-800 backdrop-blur-sm">
              <div className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mb-2">Active Missions</div>
              <div className="text-3xl font-bold text-white">{stats.openMissions}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Runtime", value: "Local + Gemini", icon: Cpu, color: "text-blue-400" },
          { label: "Secure Vault", value: "Locked", icon: Shield, color: "text-amber-400" },
          { label: "Memory", value: "1.2k items", icon: Zap, color: "text-violet-400" },
          { label: "Last Scan", value: "14m ago", icon: Clock, color: "text-slate-400" }
        ].map((item, i) => (
          <div key={i} className="p-5 rounded-3xl bg-slate-900/50 border border-slate-800 flex items-center gap-4">
            <div className={cn("p-3 rounded-2xl bg-slate-950 border border-slate-800", item.color)}>
              <item.icon className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{item.label}</div>
              <div className="text-sm font-semibold text-slate-200">{item.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <Activity className="w-4 h-4" /> Recent Timeline
            </h3>
            <button className="text-xs text-blue-400 hover:text-blue-300 font-medium">View Full History</button>
          </div>
          <div className="space-y-2">
            {recentActivity.length > 0 ? recentActivity.map((item) => (
              <div key={item.id} className="p-4 rounded-2xl bg-slate-900/30 border border-slate-800/50 flex items-center gap-4 group hover:border-slate-700 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-lg">
                  {item.event_type === "scan" ? "🔄" : "💬"}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-slate-200 font-medium truncate">{item.summary}</div>
                  <div className="text-[10px] text-slate-500 flex items-center gap-2">
                    <span>{item.project_name || "Global"}</span>
                    <span>•</span>
                    <span>{new Date(item.created_at).toLocaleTimeString()}</span>
                  </div>
                </div>
              </div>
            )) : (
              <div className="p-12 rounded-3xl border border-dashed border-slate-800 text-center space-y-2">
                <div className="text-slate-600 text-3xl">📋</div>
                <div className="text-slate-500 text-sm font-medium">No recent activity recorded.</div>
              </div>
            )}
          </div>
        </div>

        {/* Priority Missions */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <Zap className="w-4 h-4" /> Priority Missions
            </h3>
          </div>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-5 rounded-3xl bg-slate-900/50 border border-slate-800 space-y-3 group cursor-pointer hover:bg-slate-800/50 transition-all">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="text-xs font-bold text-blue-400 uppercase tracking-wider">Workspace Name</div>
                    <div className="text-sm font-semibold text-white leading-snug">Implement secure vault encryption logic</div>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]" />
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 font-medium">
                  <span>Due in 2 days</span>
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
