import React, { useState } from "react";
import { Shield, Cpu, Globe, Bell, Database, Save, RefreshCw } from "lucide-react";
import { cn } from "@/src/lib/utils";

export default function Settings() {
  const [activeSection, setActiveSection] = useState("runtime");

  const sections = [
    { id: "runtime", label: "Runtime", icon: Cpu },
    { id: "security", label: "Security", icon: Shield },
    { id: "network", label: "Network", icon: Globe },
    { id: "alerts", label: "Alerts", icon: Bell },
    { id: "storage", label: "Storage", icon: Database },
  ];

  return (
    <div className="h-full flex flex-col md:flex-row">
      {/* Sidebar */}
      <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-slate-800 p-6 space-y-2 shrink-0">
        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-4 px-4">System Settings</div>
        {sections.map((s) => (
          <button
            key={s.id}
            onClick={() => setActiveSection(s.id)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all",
              activeSection === s.id 
                ? "bg-blue-600/15 text-blue-400" 
                : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
            )}
          >
            <s.icon className="w-4 h-4" />
            {s.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-8 max-w-3xl">
        <div className="space-y-8">
          {activeSection === "runtime" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold text-white mb-1">Runtime Configuration</h3>
                <p className="text-slate-500 text-sm">Manage how Axon executes work and routes model calls.</p>
              </div>

              <div className="space-y-4">
                <div className="p-6 rounded-3xl bg-slate-900/50 border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <div className="text-sm font-semibold text-slate-200">AI Backend</div>
                      <div className="text-xs text-slate-500">Primary reasoning engine for the operator.</div>
                    </div>
                    <select className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-sm text-slate-300">
                      <option>Gemini 2.0 Flash</option>
                      <option>Local Ollama</option>
                      <option>Claude 3.5 Sonnet</option>
                    </select>
                  </div>
                </div>

                <div className="p-6 rounded-3xl bg-slate-900/50 border border-slate-800 space-y-4">
                  <div className="space-y-0.5 mb-4">
                    <div className="text-sm font-semibold text-slate-200">Workspaces Root</div>
                    <div className="text-xs text-slate-500">Directories where Axon will scan for projects.</div>
                  </div>
                  <input 
                    placeholder="~/Desktop, ~/Documents/projects"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-200 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>
            </div>
          )}

          {activeSection === "security" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold text-white mb-1">Security & Privacy</h3>
                <p className="text-slate-500 text-sm">Manage encryption, vault access, and local data safety.</p>
              </div>

              <div className="p-6 rounded-3xl bg-slate-900/50 border border-slate-800 space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="text-sm font-semibold text-slate-200">Secure Vault</div>
                    <div className="text-xs text-slate-500">AES-256-GCM encrypted storage for API keys.</div>
                  </div>
                  <button className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all border border-slate-700">
                    Unlock Vault
                  </button>
                </div>
                <div className="pt-6 border-t border-slate-800 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="text-sm font-semibold text-slate-200">PIN Protection</div>
                    <div className="text-xs text-slate-500">Require a 4-6 digit PIN for console access.</div>
                  </div>
                  <div className="w-12 h-6 rounded-full bg-slate-800 relative cursor-pointer">
                    <div className="absolute left-1 top-1 w-4 h-4 rounded-full bg-slate-500" />
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="pt-8 border-t border-slate-800 flex items-center justify-between">
            <button className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-slate-300 uppercase tracking-widest transition-colors">
              <RefreshCw className="w-4 h-4" /> Reset to Defaults
            </button>
            <button className="px-8 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold transition-all shadow-lg shadow-blue-600/20 flex items-center gap-2">
              <Save className="w-4 h-4" /> Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
