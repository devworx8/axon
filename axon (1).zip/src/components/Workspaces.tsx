import React, { useState, useEffect } from "react";
import { Search, Plus, Filter, MoreVertical, ExternalLink, GitBranch, Clock, AlertCircle } from "lucide-react";
import { cn } from "@/src/lib/utils";

export default function Workspaces() {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/projects").then(res => res.json()).then(data => {
      setProjects(data);
      setLoading(false);
    });
  }, []);

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Workspaces</h1>
          <p className="text-slate-500 text-sm">Monitor health and activity across your local projects.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              placeholder="Search workspaces..."
              className="pl-10 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-200 focus:border-blue-500/50 transition-all w-64"
            />
          </div>
          <button className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors">
            <Filter className="w-4 h-4" />
          </button>
          <button className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold transition-all flex items-center gap-2">
            <Plus className="w-4 h-4" /> New Workspace
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {loading ? (
          [1, 2, 3].map(i => (
            <div key={i} className="h-48 rounded-3xl bg-slate-900/50 border border-slate-800 animate-pulse" />
          ))
        ) : projects.length > 0 ? (
          projects.map((p) => (
            <div key={p.id} className="p-6 rounded-3xl bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-all group cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center text-2xl">
                    {p.stack === "python" ? "🐍" : p.stack === "node" ? "🟢" : "💻"}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors">{p.name}</h3>
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{p.stack || "Unknown Stack"}</div>
                  </div>
                </div>
                <button className="p-1 rounded-lg hover:bg-slate-800 text-slate-600 transition-colors">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <GitBranch className="w-3 h-3" /> {p.git_branch || "main"}
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <Clock className="w-3 h-3" /> {p.last_commit_age_days ? `${Math.round(p.last_commit_age_days)}d ago` : "No commits"}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest">
                    <span className="text-slate-500">Workspace Health</span>
                    <span className={cn(
                      p.health >= 80 ? "text-emerald-400" : p.health >= 50 ? "text-amber-400" : "text-rose-400"
                    )}>{p.health}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div 
                      className={cn(
                        "h-full rounded-full transition-all duration-500",
                        p.health >= 80 ? "bg-emerald-500" : p.health >= 50 ? "bg-amber-500" : "bg-rose-500"
                      )}
                      style={{ width: `${p.health}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-slate-400 font-bold">
                    {p.todo_count || 0} TODOs
                  </span>
                </div>
                <button className="text-[10px] font-bold text-blue-400 hover:text-blue-300 uppercase tracking-widest flex items-center gap-1">
                  Inspect <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full p-12 rounded-3xl border border-dashed border-slate-800 text-center space-y-4">
            <div className="text-slate-600 text-5xl">📁</div>
            <div className="space-y-1">
              <div className="text-slate-300 font-bold">No workspaces found</div>
              <p className="text-slate-500 text-sm max-w-xs mx-auto">Run an environment scan to automatically discover your local projects.</p>
            </div>
            <button className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold transition-all border border-slate-700">
              Run Initial Scan
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
