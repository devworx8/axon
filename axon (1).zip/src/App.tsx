import React, { useState } from "react";
import { 
  LayoutDashboard, 
  MessageSquare, 
  FolderKanban, 
  CheckSquare, 
  Settings as SettingsIcon,
  Activity,
  Scan,
  Smartphone,
  ChevronLeft,
  ChevronRight,
  Bell,
  Search,
  Cpu
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/src/lib/utils";

// Components
import Dashboard from "./components/Dashboard";
import Console from "./components/Console";
import Workspaces from "./components/Workspaces";
import Missions from "./components/Missions";
import SettingsPage from "./components/Settings";

type Tab = "dashboard" | "console" | "workspaces" | "missions" | "settings";

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isScanning, setIsScanning] = useState(false);

  const navItems = [
    { id: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { id: "console", icon: MessageSquare, label: "Console" },
    { id: "workspaces", icon: FolderKanban, label: "Workspaces" },
    { id: "missions", icon: CheckSquare, label: "Missions" },
    { id: "settings", icon: SettingsIcon, label: "Settings" },
  ];

  const handleScan = async () => {
    setIsScanning(true);
    try {
      const res = await fetch("/api/scan", { method: "POST" });
      const data = await res.json();
      if (data.status === "success") {
        // Refresh data if on dashboard or workspaces
        window.location.reload(); // Simple way for now
      }
    } catch (err) {
      console.error("Scan failed:", err);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden font-sans selection:bg-blue-500/30">
      {/* Sidebar */}
      <aside className={cn(
        "flex flex-col bg-slate-900 border-r border-slate-800 transition-all duration-300 ease-in-out shrink-0",
        isSidebarOpen ? "w-64" : "w-20"
      )}>
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 via-blue-600 to-cyan-300 flex items-center justify-center text-slate-950 font-black text-xl shadow-lg shadow-cyan-500/25 border border-white/10">
              ✦
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-slate-900 bg-emerald-400" />
          </div>
          {isSidebarOpen && (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="min-w-0"
            >
              <div className="font-bold text-white text-lg tracking-tight">Axon</div>
              <div className="text-[10px] text-cyan-400/70 uppercase tracking-[0.22em] font-bold">Operator</div>
            </motion.div>
          )}
        </div>

        <nav className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as Tab)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all group relative",
                activeTab === item.id 
                  ? "bg-blue-600/15 text-blue-400" 
                  : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
              )}
            >
              <item.icon className={cn("w-5 h-5 shrink-0", activeTab === item.id ? "text-blue-400" : "text-slate-400 group-hover:text-slate-200")} />
              {isSidebarOpen && <span>{item.label}</span>}
              {activeTab === item.id && (
                <motion.div 
                  layoutId="activeTab"
                  className="absolute left-0 w-1 h-6 bg-blue-500 rounded-r-full"
                />
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800 space-y-2">
          <button 
            onClick={handleScan}
            disabled={isScanning}
            className="w-full flex items-center gap-3 px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition-all disabled:opacity-50"
          >
            <Scan className={cn("w-4 h-4", isScanning && "animate-spin")} />
            {isSidebarOpen && <span>{isScanning ? "Scanning..." : "Axon Scan"}</span>}
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition-all">
            <Smartphone className="w-4 h-4" />
            {isSidebarOpen && <span>Mobile Link</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <header className="h-16 border-b border-slate-800 bg-slate-950/50 backdrop-blur-md flex items-center justify-between px-8 shrink-0 z-10">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 transition-colors"
            >
              <Activity className="w-5 h-5" />
            </button>
            <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-widest">
              {activeTab}
            </h2>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {activeTab === "dashboard" && <Dashboard />}
              {activeTab === "console" && <Console />}
              {activeTab === "workspaces" && <Workspaces />}
              {activeTab === "missions" && <Missions />}
              {activeTab === "settings" && <SettingsPage />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
