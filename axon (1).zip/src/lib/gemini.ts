import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const model = "gemini-2.0-flash-exp";

export async function chat(message: string, history: any[] = []) {
  const response = await ai.models.generateContent({
    model: model,
    contents: [
      ...history,
      { role: "user", parts: [{ text: message }] }
    ],
    config: {
      systemInstruction: `You are Axon, a local AI Operator for a software developer.
You help them stay focused, organised, and productive.
Your personality:
- Direct and concise — no fluff, no padding.
- Proactively flag risks (stale workspaces, overdue missions).
- When asked about code, give concrete actionable answers.
- You operate within a local-first context.

Format rules:
- Use markdown for structure.
- Keep lists short (max 5 items).
- Prefer bullet points over paragraphs.`
    }
  });

  return response.text;
}
