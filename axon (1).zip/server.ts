import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { DatabaseSync } from "node:sqlite";

const DB_PATH = path.join(process.cwd(), "axon.db");
let db: any;

async function initDb() {
  db = new DatabaseSync(DB_PATH);
  db.exec(`
    CREATE TABLE IF NOT EXISTS projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      path TEXT NOT NULL,
      stack TEXT,
      health INTEGER DEFAULT 100,
      git_branch TEXT,
      last_commit TEXT,
      last_commit_age_days REAL,
      todo_count INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      detail TEXT,
      priority TEXT DEFAULT 'medium',
      status TEXT DEFAULT 'open',
      project_id INTEGER,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS activity_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_type TEXT NOT NULL,
      summary TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);
}

async function seedDb() {
  const row = db.prepare("SELECT COUNT(*) as count FROM projects").get();
  if (row?.count === 0) {
    const projects = [
      { name: "Axon Core", path: "~/projects/axon", stack: "nextjs", health: 92, git_branch: "main", last_commit: "Initial commit", last_commit_age_days: 0.1, todo_count: 5 },
      { name: "Nexus API", path: "~/projects/nexus", stack: "python", health: 78, git_branch: "develop", last_commit: "Add auth middleware", last_commit_age_days: 2.5, todo_count: 12 },
      { name: "Lumina UI", path: "~/projects/lumina", stack: "node", health: 45, git_branch: "feature/redesign", last_commit: "Update tailwind config", last_commit_age_days: 14, todo_count: 42 }
    ];
    
    const insert = db.prepare("INSERT INTO projects (name, path, stack, health, git_branch, last_commit, last_commit_age_days, todo_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    projects.forEach(p => {
      insert.run(p.name, p.path, p.stack, p.health, p.git_branch, p.last_commit, p.last_commit_age_days, p.todo_count);
    });
    
    db.exec("INSERT INTO activity_log (event_type, summary) VALUES ('scan', 'Initial environment scan complete. Found 3 workspaces.')");
  }
}

async function startServer() {
  try {
    await initDb();
    await seedDb();
  } catch (err) {
    console.error("DB Error:", err);
  }

  const app = express();
  const port = 3000;

  app.use(express.json());

  app.get("/api/health", (req, res) => {
    res.send({ status: "ok" });
  });

  app.get("/api/projects", (req, res) => {
    try {
      const rows = db.prepare("SELECT * FROM projects ORDER BY health ASC, name ASC").all();
      res.json(rows);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/tasks", (req, res) => {
    try {
      const rows = db.prepare(`
        SELECT t.*, p.name as project_name 
        FROM tasks t 
        LEFT JOIN projects p ON t.project_id = p.id 
        ORDER BY 
          CASE t.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
          t.created_at DESC
      `).all();
      res.json(rows);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/activity", (req, res) => {
    try {
      const rows = db.prepare(`
        SELECT a.*, p.name as project_name 
        FROM activity_log a 
        LEFT JOIN projects p ON a.project_id = p.id 
        ORDER BY a.created_at DESC LIMIT 50
      `).all();
      res.json(rows);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/scan", (req, res) => {
    try {
      // Simulate a scan finding a new project
      const newProject = {
        name: `Project_${Math.floor(Math.random() * 1000)}`,
        path: `/home/operator/src/new-project-${Math.floor(Math.random() * 100)}`,
        stack: ["node", "python", "nextjs", "go"][Math.floor(Math.random() * 4)],
        health: Math.floor(Math.random() * 40) + 60,
        git_branch: "main",
        last_commit: "Initial scan discovery",
        last_commit_age_days: 0,
        todo_count: Math.floor(Math.random() * 10)
      };

      const insert = db.prepare("INSERT INTO projects (name, path, stack, health, git_branch, last_commit, last_commit_age_days, todo_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
      insert.run(newProject.name, newProject.path, newProject.stack, newProject.health, newProject.git_branch, newProject.last_commit, newProject.last_commit_age_days, newProject.todo_count);

      db.exec(`INSERT INTO activity_log (event_type, summary) VALUES ('scan', 'Manual scan completed. Discovered new workspace: ${newProject.name}')`);

      res.json({ status: "success", project: newProject });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vault Endpoints (Mocked for now)
  app.get("/api/vault/status", (req, res) => {
    res.json({ locked: true, last_accessed: null });
  });

  app.post("/api/vault/unlock", (req, res) => {
    const { password } = req.body;
    if (password === "axon2026") {
      res.json({ status: "success", token: "vault_session_active" });
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  });

  console.log("Initializing Vite...");
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });

  app.use(vite.middlewares);

  app.get("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      let template = fs.readFileSync(path.resolve(process.cwd(), "index.html"), "utf-8");
      template = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(template);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });

  app.listen(port, "0.0.0.0", () => {
    console.log(`Server listening on port ${port}`);
  });
}

startServer().catch(console.error);
